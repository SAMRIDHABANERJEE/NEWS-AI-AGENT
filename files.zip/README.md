# 📰 News AI Agent

An **n8n-powered AI agent** that fetches the latest Tesla news via [NewsAPI](https://newsapi.org), summarises it using OpenAI GPT, and sends the digest to your inbox via Gmail — all triggered by a simple chat message.

---

## 🏗️ Architecture

```
Chat Message  ──►  AI Agent (GPT-4o-mini)
                        │
              ┌─────────┴──────────┐
              ▼                    ▼
       HTTP Request           Gmail Tool
      (NewsAPI fetch)       (Send email digest)
              │
        Simple Memory
       (conversation ctx)
```

| Node | Purpose |
|---|---|
| **Chat Trigger** | Receives user chat messages to start the workflow |
| **AI Agent** | Orchestrates tools using LangChain |
| **OpenAI Chat Model** | GPT-4o-mini powers the agent reasoning |
| **Simple Memory** | Keeps conversation context across turns |
| **HTTP Request Tool** | Fetches Tesla news from NewsAPI |
| **Gmail Tool** | Sends the AI-summarised news digest by email |

---

## 🚀 Quick Start

### Prerequisites
- [Docker](https://docs.docker.com/get-docker/) & [Docker Compose](https://docs.docker.com/compose/)
- An [OpenAI API key](https://platform.openai.com/api-keys)
- A [NewsAPI key](https://newsapi.org/account) (free tier works)
- A Gmail account with OAuth2 set up in n8n

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/news-ai-agent.git
cd news-ai-agent
```

### 2. Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in all required values (see [Environment Variables](#-environment-variables) below).

### 3. Start n8n

```bash
docker compose up -d
```

n8n will be available at **http://localhost:5678**

### 4. Import the workflow

1. Log in to n8n (`admin` / your chosen password).
2. Go to **Workflows → Import from File**.
3. Select `workflows/NEWS_AI_AGENT.json`.
4. Set up credentials (see below).
5. **Activate** the workflow using the toggle.

---

## 🔑 Credentials Setup in n8n

### OpenAI
1. In n8n, go to **Credentials → New → OpenAI**.
2. Paste your `OPENAI_API_KEY`.
3. Assign it to the **OpenAI Chat Model** node.

### Gmail (OAuth2)
1. Go to **Credentials → New → Gmail OAuth2**.
2. Follow the OAuth flow to authorise your Google account.
3. Assign it to the **Send a message in Gmail** node.

### NewsAPI (via HTTP Request)
The API key is injected from the environment variable `NEWS_API_KEY` directly in the URL — no separate credential node needed.

---

## 🌍 Environment Variables

| Variable | Description | Required |
|---|---|---|
| `OPENAI_API_KEY` | Your OpenAI secret key | ✅ |
| `NEWS_API_KEY` | Your NewsAPI.org key | ✅ |
| `RECIPIENT_EMAIL` | Email address to receive news digests | ✅ |
| `N8N_BASIC_AUTH_USER` | n8n login username | ✅ |
| `N8N_BASIC_AUTH_PASSWORD` | n8n login password | ✅ |
| `N8N_ENCRYPTION_KEY` | Random 32-char string to encrypt credentials | ✅ |
| `WEBHOOK_URL` | Public URL of your n8n instance | ✅ |
| `GENERIC_TIMEZONE` | Your timezone (e.g. `Asia/Kolkata`) | Optional |

---

## 💬 Usage

Once the workflow is active, open the **Chat** interface in n8n (or hit the webhook URL) and send a message like:

```
Fetch the latest Tesla news and email me a summary.
```

The agent will:
1. Call NewsAPI for recent Tesla articles.
2. Summarise the top stories using GPT.
3. Send the digest to your configured email address.

---

## 🔧 Customisation

| What to change | Where |
|---|---|
| **Topic** (currently Tesla) | Edit the `q=tesla` param in the HTTP Request node URL |
| **Date range** | Edit the `from=` param in the HTTP Request URL |
| **Recipient email** | Update `RECIPIENT_EMAIL` in `.env` or hardcode in the Gmail node |
| **AI model** | Change `gpt-4o-mini` to any supported OpenAI model in the Chat Model node |

---

## 🛡️ Security Notes

- **Never** commit your real `.env` file — it is listed in `.gitignore`.
- Rotate your `N8N_ENCRYPTION_KEY` if you suspect it has been exposed.
- Use a strong `N8N_BASIC_AUTH_PASSWORD` in production.
- For production deployments, put n8n behind a reverse proxy (Nginx/Caddy) with HTTPS.

---

## 📁 Repository Structure

```
news-ai-agent/
├── workflows/
│   └── NEWS_AI_AGENT.json   # n8n workflow export
├── .env.example             # Template for environment variables
├── .gitignore               # Keeps secrets out of Git
├── docker-compose.yml       # One-command deployment
└── README.md                # You are here
```

---

## 📄 License

MIT License – feel free to fork and customise.
